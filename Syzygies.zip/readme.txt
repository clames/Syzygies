1. bonus1.py und wordsEn.txt im gleichen Pfad abspeichern.
2. bonus1.py starten
3. Start und Ende angeben